
#include <vtkTextProperty.h>
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>
#include <vtkSliderWidget.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkCommand.h>
#include <vtkWidgetEvent.h>
#include <vtkCallbackCommand.h>
#include <vtkWidgetEventTranslator.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkSliderWidget.h>
#include <vtkSliderRepresentation2D.h>
#include <vtkProperty.h>

#include <vtkSampleFunction.h>
#include <vtkContourFilter.h>
#include <vtkQuadric.h>

class CountourFunctionSlider : public vtkCommand
{
public:
  static CountourFunctionSlider *New()
  {
    return new CountourFunctionSlider;
  }
  virtual void Execute(vtkObject *caller, unsigned long, void*) VTK_OVERRIDE
  {
    vtkSliderWidget *sliderWidget =
      reinterpret_cast<vtkSliderWidget*>(caller);

    double value = static_cast<int>(static_cast<vtkSliderRepresentation *>(sliderWidget->GetRepresentation())->GetValue());
    this->QuadraticSource->SetValue(0, (value));
  }
  CountourFunctionSlider():QuadraticSource(0) {}
  vtkContourFilter* QuadraticSource;
};

int main (int, char *[])
{
//Creating a mapper and actor

vtkSmartPointer<vtkQuadric> QuadricFun =
vtkSmartPointer<vtkQuadric>::New();	

QuadricFun->SetCoefficients(1,0.6,0.25,0,0,0.1,0.2,0,0,0);

vtkSmartPointer<vtkSampleFunction> SampleFun =
vtkSmartPointer<vtkSampleFunction>::New();	


SampleFun->SetSampleDimensions(70,70,70);
SampleFun->SetImplicitFunction(QuadricFun);
double xmin = -10, xmax = 11, ymin = -10, ymax = 10, zmin = -10, zmax = 10;
SampleFun->SetModelBounds(xmin, xmax, ymin, ymax, zmin, zmax);


 // Generate implicit surface
vtkSmartPointer<vtkContourFilter> contourFunction =
vtkSmartPointer<vtkContourFilter>::New();	
contourFunction->SetInputConnection(SampleFun->GetOutputPort());
contourFunction->GenerateValues(1, 1.0, 1.0);

// Map contour
vtkSmartPointer<vtkPolyDataMapper> contourMapper =
vtkSmartPointer<vtkPolyDataMapper>::New();
contourMapper->SetInputConnection(contourFunction->GetOutputPort());
contourMapper->SetScalarRange(0,7);
// actor

  vtkSmartPointer<vtkActor> actorFun =
  vtkSmartPointer<vtkActor>::New();
  actorFun->SetMapper(contourMapper);

  //Create a renderer, render window, and interactor
  vtkSmartPointer<vtkRenderer> rendererFun =
    vtkSmartPointer<vtkRenderer>::New();
  vtkSmartPointer<vtkRenderWindow> renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(rendererFun);
  vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);

  //Adding the actors to the scene
  rendererFun->AddActor(actorFun);
  renderWindow->Render();
  //======================
  vtkSmartPointer<vtkSliderRepresentation2D> sliderRepFun =
    vtkSmartPointer<vtkSliderRepresentation2D>::New();
  
  sliderRepFun->SetMinimumValue(1.0);
  sliderRepFun->SetMaximumValue(100.0);
  sliderRepFun->SetValue(50);
  sliderRepFun->SetTitleText("Slider Resolution");

  sliderRepFun->GetPoint1Coordinate()->SetCoordinateSystemToDisplay();
  sliderRepFun->GetPoint1Coordinate()->SetValue(100 ,50);
  sliderRepFun->GetPoint2Coordinate()->SetCoordinateSystemToDisplay();
  sliderRepFun->GetPoint2Coordinate()->SetValue(150, 50);
  
  vtkSliderWidget *sliderWidgetFun = vtkSliderWidget::New();
  sliderWidgetFun->SetInteractor(renderWindowInteractor);
  sliderWidgetFun->SetRepresentation(sliderRepFun);
  sliderWidgetFun->SetAnimationModeToAnimate();
  sliderWidgetFun->EnabledOn();
 
 /* vtkSmartPointer<vtkCounterCallback> callback =
    vtkSmartPointer<vtkCounterCallback>::New();
  callback->ContourFilter = contour;
  */
  CountourFunctionSlider*callback = CountourFunctionSlider::New();
  callback->QuadraticSource = contourFunction;
  
  sliderWidgetFun->AddObserver(vtkCommand::InteractionEvent,callback);
 
  renderWindowInteractor->Initialize();
  renderWindow->Render();
  //============================
  
  
  rendererFun->SetBackground(0.1, 0.2, 0.4);

  //Render and interact
  
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
 
}