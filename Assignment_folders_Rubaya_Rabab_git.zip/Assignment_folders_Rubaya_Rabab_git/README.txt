The 'Assignment_folders_Rubaya_Rabab' contains two vtk code folder-
1)CtExample
2)QuadraticSlider2D
--------------------------------
The 'CtExample' folder contains one src and one bin folder
important note: please include headsq dataset folder in src folder before run the code.
and inside code you have to change a line -
v16CThead->SetFilePrefix("C:\\Users\\HP\\Desktop\\CtExample\\src\\headsq\\half");
here path of the headsq will be changed.
inside src there are two files-
1)CMakeLists.txt
2)ctslider.cxx 
3)headsq 
inside bin-
Debug folder presents, which contains ctslider.exe file 
-------------------------
The 'QuadraticSlider2D' folder contains one src and one bin folder
inside src there are two files-
1)CMakeLists.txt
2)QuadraticSlider2D.cxx 
inside bin-
Debug folder presents, which contains QuadraticSlider2D.exe file 