#include <vtkSphereSource.h>
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>

#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkCommand.h>

#include <vtkProperty.h>
#include "vtkVolume16Reader.h"
#include <vtkMarchingCubes.h>

#include <vtkWidgetEvent.h>
#include <vtkCallbackCommand.h>
#include <vtkWidgetEventTranslator.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkSliderWidget.h>
#include <vtkSliderRepresentation2D.h>
 
class MarchingCubesSlider : public vtkCommand
{
public:
  static MarchingCubesSlider *New()
  {
    return new MarchingCubesSlider;
  }
  virtual void Execute(vtkObject *caller, unsigned long, void*) VTK_OVERRIDE
  {
    vtkSliderWidget *sliderWidget =
      reinterpret_cast<vtkSliderWidget*>(caller);

    double value = static_cast<int>(static_cast<vtkSliderRepresentation *>(sliderWidget->GetRepresentation())->GetValue());
    this->MarchingCube->SetValue(0, (value));
  }
  MarchingCubesSlider():MarchingCube(0) {}
  vtkMarchingCubes* MarchingCube;
};
 
int main (int, char *[])
{
	vtkSmartPointer<vtkVolume16Reader> v16CThead =
    vtkSmartPointer<vtkVolume16Reader>::New();
    
  // Read in the data.

	v16CThead->SetDataDimensions(128,128);
	v16CThead->SetFilePrefix("C:\\Users\\HP\\Desktop\\CtExample\\src\\headsq\\half");
	v16CThead->SetImageRange(1,93);
	v16CThead->SetDataByteOrderToLittleEndian();
	v16CThead->SetDataSpacing(1.0,1.0,1.0);
	

	vtkSmartPointer<vtkMarchingCubes> isoCThead =
    vtkSmartPointer<vtkMarchingCubes>::New();
	isoCThead->SetInputConnection(v16CThead->GetOutputPort());
	isoCThead->SetValue(0,1150);

	//  creating iso mapper and iso actor.
	vtkSmartPointer<vtkPolyDataMapper> isoMapperCthead =
    vtkSmartPointer<vtkPolyDataMapper>::New();
	isoMapperCthead->SetInputConnection(isoCThead->GetOutputPort());
	isoMapperCthead->ScalarVisibilityOff();
	
	vtkSmartPointer<vtkActor> isoActorCThead =
    vtkSmartPointer<vtkActor>::New();
	isoActorCThead->SetMapper(isoMapperCthead);
	

	// creating renderer and render window
	vtkSmartPointer<vtkRenderer> rendererCThead =
    vtkSmartPointer<vtkRenderer>::New();
	vtkSmartPointer<vtkRenderWindow> renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
	renderWindow->AddRenderer(rendererCThead);
 
	// interactor
	vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
	renderWindowInteractor->SetRenderWindow(renderWindow);
 
   // Add the actors to the scene
	rendererCThead->AddActor(isoActorCThead);
 
   // Render an image (lights and cameras are created automatically)
   renderWindow->Render();
 //=============slider=========
	vtkSmartPointer<vtkSliderRepresentation2D> sliderCTRep =
    vtkSmartPointer<vtkSliderRepresentation2D>::New();
  
	sliderCTRep->SetMinimumValue(1.0);
	sliderCTRep->SetMaximumValue(50.0);
	sliderCTRep->SetValue(50);
	
	sliderCTRep->SetSliderLength(0.05);
    sliderCTRep->SetSliderWidth(0.05);
	sliderCTRep->SetTitleText("Slider Resolution of CT head");

	sliderCTRep->GetPoint1Coordinate()->SetCoordinateSystemToDisplay();
	sliderCTRep->GetPoint1Coordinate()->SetValue(50 ,50);
	sliderCTRep->GetPoint2Coordinate()->SetCoordinateSystemToDisplay();
	sliderCTRep->GetPoint2Coordinate()->SetValue(150, 50);
	
    vtkSmartPointer<vtkSliderWidget> sliderCTWidget =
    vtkSmartPointer<vtkSliderWidget>::New();
	sliderCTWidget->SetInteractor(renderWindowInteractor);
	sliderCTWidget->SetRepresentation(sliderCTRep);
	sliderCTWidget->SetAnimationModeToAnimate();
	sliderCTWidget->EnabledOn();
  

	MarchingCubesSlider *sliderCT = MarchingCubesSlider::New();
	sliderCT->MarchingCube = isoCThead;
 
	sliderCTWidget->AddObserver(vtkCommand::InteractionEvent,sliderCT);
	//Render and interact
	renderWindowInteractor->Initialize();
	renderWindow->Render();
	//============================
 
	renderWindowInteractor->Initialize();
	renderWindow->Render();
	// setting color of background
	rendererCThead->SetBackground(0.1, 0.2, 0.4);
	renderWindowInteractor->Start();
 
	return EXIT_SUCCESS;

}